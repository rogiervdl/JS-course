# Full ES2015 Example

Example with generators and promises in Node

