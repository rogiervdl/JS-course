print('You passed ' + arguments.length + ' arguments to this script');
for (var i = 0, l = arguments.length; i < l; i++) {
	print('- argument #' + i + ' : ' + arguments[i]);
}