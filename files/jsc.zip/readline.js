print('What\'s your name?');
var name = readline();
print('Hello ' + name);